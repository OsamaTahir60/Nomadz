import 'package:flutter/material.dart';

Color kgreenColor = Color(0Xff3F852B);

Color textColor = Colors.black;
Color kblueColor = Color(0xff488DAC);
Color klightGreyColor = Color(0xffB1B1B1);
Color bgColor = Color(0xffF1F1F1);
Color homecardColor = Color(0xffFeebc1);
