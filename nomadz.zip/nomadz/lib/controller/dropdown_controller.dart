import 'package:get/get_state_manager/get_state_manager.dart';

class DropdownController extends GetxController {
  String selectedDrowpdown = "Estate";
  List<String> dropdownText = [
    "Hatchback",
    "Estate",
    "SUV",
    "Saloon",
    "MPV",
  ];
}
